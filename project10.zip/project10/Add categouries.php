
<?php

include "categories list.php"
?>


<!DOCTYPE html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script> 
    <title>Dashboard</title>
 
   
    <title>Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background-color: #333;
            color: white;
            padding: 15px;
            text-align: center;
        }

        nav {
            width: 200px;
            background-color: #f4f4f4;
            padding: 15px;
            position: fixed;
            height: 25%;
            overflow: auto;
        }

        nav a {
            display: block;
            padding: 15px;
            text-decoration: none;
            color: blue;
            border-bottom: 2px solid blue;
            border-right: 2px solid blue;
            border-left: 2px solid blue;
            border-top: 2px solid blue;
           
        }

        nav a:hover {
            background-color: #ddd;
        }

        .div {
            margin: 80px 0 0 220px;
            display: flex;
            justify-content: space-evenly;
        }

        .text p {
            color: blue;
            font-size: 20px;
            margin: 100px 0 0 300px;
        }
        h3{
            margin: 30px 0 0 41%;
            position: absolute;
            margin-top:-23%;
            color:blue;
        }
        .cat-icon span{
            position:absolute;
            color:blue;
            font-size:200px;
            margin-top:-20%;
            margin-left:36%;
            border-radius:50%;
            border:2px solid blue;
            padding: 20px;
                    
        }
        .btn button {
            color: blue;
            padding: 10px;
            width: 25%;
            border: 2px solid blue;
            margin: 50px 0 0 30%;
        }

        .div{
             position: absolute;
            display:none;
        }

        .col-6:hover +.div {
           
            display: block;
            color:black;
            
        }
        .div-icon{
            display:none;
        }
        .cat-icon:hover +.div-icon {
            position: absolute;
            position: absolute;
            display: block;
            color:black;
            
        }
        .div p{
            color:blue;
            margin:-110px 0 0 400px;
            border:2px solid blue;
            padding: px;
            width: 40%;
        }
        .div-icon p{
          
            color:blue;
            margin:-250px 0 0 800px;
            border:2px solid blue;
            padding: 15px;
        }

        .col-6{
            margin-top:80px;
            margin-left:145px;
        }
        .d-grid {
            margin:26% 0 0 28%;
           
        }
    </style>
</head>
<body>

    <header>
        <h1>Dashboard</h1>
    </header>

    <nav>
        <a href="Home.php" class="active">Dashboard</a>
        <a href="index.php">Categories</a>
        <a href="product page.php">Product</a>
    </nav>
    
    <div class="text">
        <p>Categories Add</p>
    </div>

    <form action="insert.php" method="POST">
        <div class="container">
            <div class="t-center m-auto mt-8 py-2 col-md-8">
                <div class="col-6">
                    <input type="text" name="list" class="form-control"> 
                </div>
                <div class="div">
                    <p>Categories Name must be <br> unique. Required</p>
                </div>
            </div>
            <div class="d-grid gap-1 col-4">
                <button type="submit" class="btn btn-outline-primary">Add New Categories</button> 
            </div>
        </div>
    </form> 

    <h3>Cat Icon</h3>

    <div class="cat-icon">
        <span class="material-symbols-outlined">mail</span>
    </div> 

    <div class="div-icon">
        <p>Categories Icon Required</p>
    </div>

</body>
</html>


    
