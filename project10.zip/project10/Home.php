<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background-color: #333;
            color: white;
            padding: 15px;
            text-align: center;
        }

        nav {
            width: 200px;
            background-color: #f4f4f4;
            padding: 15px;
            position: fixed;
            height: 25%;
            overflow: auto;
        }

        nav a {
            display: block;
            padding: 15px;
            text-decoration: none;
            color: blue;
            border-bottom: 2px solid blue;
            border-right: 2px solid blue;
            border-left: 2px solid blue;
            border-top: 2px solid blue;
            overflow: hidden;
        }

        nav a:hover {
            background-color: #ddd;
        }

        .div {
            margin: 80px 0 0 220px;
            display: flex;
            justify-content: space-evenly;
        }

        .text {
            border: 2px solid blue;
            padding: 70px;
            background-color: lightgray;
            width:15%;
            text-align: center;
            background-color: #f4f4f4;
        }

        .text p {
            position: absolute;
            margin: -10px 0 0 -6.5%;
            color: blue;
            width:20%;
        }

        .text h4 {
            margin: 50px 0 0 0px;
            color: blue;
        }

        .text h1 {
            color: blue; 
        }
       
    </style>
</head>
<body>

    <header class="bg-dark text-white">
        <h1>Dashboard</h1>
    </header>

    <nav class="bg-light">
        <a href="#" class="text-dark">Dashboard</a>
        <a href="index.php" class="text-dark">Categories</a>
        <a href="product page.php" class="text-dark">Product</a>
    </nav>

    <div class="div">
        <div class="text border border-2 border-primary rounded p-5">
            <p >Total Categories</p><br><br>
            <?php
                include 'categories list.php';
                $query = "SELECT id FROM tabletodo ORDER BY id";
                $query_run = mysqli_query($con, $query);
                $rows = mysqli_num_rows($query_run);
                echo '<h1 class="text-primary">' . $rows . '</h1>';
            ?>
        </div>
        <div class="text border border-2 border-primary rounded p-5">
            <p>Total Product</p><br><br>
            <?php
                include 'categories list.php';
                $query = "SELECT id FROM tabletodo ORDER BY id";
                $query_run = mysqli_query($con, $query);
                $rows = mysqli_num_rows($query_run);
                echo '<h1 class="text-primary">' . $rows . '</h1>';
            ?>
           
        </div>
    </div>

</body>
</html>
