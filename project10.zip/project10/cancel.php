<?php
 include "categories list.php";

  $id = $_GET['ID'];
  mysqli_query($con,"DELETE FROM tabletodo WHERE  ID= $id");
  header("location:index.php");

?>