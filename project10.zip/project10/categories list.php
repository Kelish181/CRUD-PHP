<?php


$servername='localhost';
$username='root';

$dbname = "crud";



$con = mysqli_connect("localhost", "root", "", "todo") or die("Connection failed");
if(!$con){
    die('Could not Connect My Sql:' .mysql_error());
 }


?>
