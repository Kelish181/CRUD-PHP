<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <title>Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background-color: #333;
            color: white;
            padding: 15px;
            text-align: center;
        }

        nav {
            width: 200px;
            background-color: #f4f4f4;
            padding: 15px;
            position: fixed;
            height: 20%;
            overflow: auto;
        }

        nav a {
            display: block;
            padding: 15px;
            text-decoration: none;
            color: blue;
            border-bottom: 2px solid blue;
            border-right: 2px solid blue;
            border-left: 2px solid blue;
            border-top: 2px solid blue;
           
        }

        nav a:hover {
            background-color: #ddd;
        }

        .div {
            margin: 80px 0 0 220px;
            display: flex;
            justify-content: space-evenly;
        }

        .text p {
            color: blue;
            font-size: 20px;
            margin: 100px 0 0 300px;
        }

        .btn button {
            color: blue;
            padding: 10px;
            width: 10%;
            border: 2px solid blue;
            margin: -10px 0 0 85%;
        }

      

        .colum{
            border-left:2px solid blue;
            height:50.3vh;
            margin-left:25.1%;
            margin-top:-27%;
        }

        .btn-btn{
            position: absolute;
            margin-left: 83%;
            margin-top: -25px;
           
        }

        .btn-{
            position: absolute;
            margin-left: 85%;
            margin-top: -45px;

        }
        .container input{
            position: relative;
            margin: 30px 0 0 30%;
            width: 60%;
            height: 50px;
            border: 2px solid blue;
        }

        .container input:hover{
            border:2px solid blue;
        }
    
    </style>
</head>
<body>

    <header>
        <h1>Dashboard</h1>
    </header>

    <nav>
        <a href="Home.php">Dashboard</a>
        <a href="categouries page.php">Categories</a>
        <a href="product page.php">Product</a>
    </nav>
    
        <div class="text">
            <p>Categories List</p>
        </div>
    
    <div class="btn">
        <a href="Add categouries.php"><button>Add New Categories</button></a>
    </div>
    <form action="insert.php" method="POST">
 
        
           <span class="material-symbols-outlined"style="color:blue; font-size:40px;">
            warning
            </span>
            <div class="container">
                <div class="row">
             <input type="text" name="list" class="form-control" placeholder="Cat name";>
             </div>
             <div class="btn-btn">
             <button class="material-symbols-outlined" style="margin-left: 10px; color: blue;border-radius: 50%;border: 2px solid blue;padding: 5px;position:absolute;margin-left: 78%;margin-top:-20px;">edit</button>
             </div>


               <div class="btn-">
                <button class="material-symbols-outlined" style="margin-left: 10px; color: blue;border-radius: 50%;position:absolute;border: 2px solid blue;padding: 5px;position: absolute;">cancel</button>

                </div>
                </div>
         

</form>
</body>
</html>
