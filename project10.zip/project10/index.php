<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Dashboard</title>
    <style>
           body {
            margin: 0;
            font-family: Arial, sans-serif;
            /* background-color:blue; */
        }

        header {
            background-color: #333;
            color: white;
            padding: 15px;
            text-align: center;
        }

        nav {
            width: 200px;
            background-color: #f4f4f4;
            padding: 10px;
            position: fixed;
            height: 25%;
        }
        .update-form {
            display: flex;
            align-items: center;
        }

        .update-form input {
            margin-right: 10px;
        }

        nav a {
            display: block;
            padding: 15px;
            text-decoration: none;
            color: blue;
            border-bottom: 2px solid blue;
            border-right: 2px solid blue;
            border-left: 2px solid blue;
            border-top: 2px solid blue;
        }

        nav a:hover {
            background-color: #ddd;
        }

        .div {
            margin: 80px 0 0 220px;
            display: flex;
            justify-content: space-evenly;
        }

        .text p {
            color: blue;
            font-size: 20px;
            margin: 100px 0 0 300px;
        }

        .container input {
            position: relative;
            margin: 30px 0 0 30%;
            width: 60%;
            height: 50px;
            border: 2px solid blue;
        }

        .container input:hover {
            border: 2px solid blue;
        }

        .d-grid {
            position: relative;
            margin: -30px 0 0 75%;
        }

        form {
            margin-top: 2%;
            margin-left: 15%;
        }
        /* .btn btn-primary.fa-solid {
            position: relative;
            margin:0 0 0 10%;
        } */
        /* Add your styling here */
    </style>
</head>

<body>

    <header>
        <h1>Dashboard</h1>
    </header>
    <nav>
        <a href="Home.php">Dashboard</a>
        <a href="index.php">Categories</a>
        <a href="product page.php">Product</a>
    </nav>

    <div class="text">
        <p>Categories List</p>
    </div>

    <div class="d-grid gap-1 col-2">
        <a href="Add categouries.php"><button type="submit" class="btn btn-outline-primary">Add New Categories</button></a>
    </div>

    <form action="insert.php" method="POST">
        <?php
        include "categories list.php";
        $rawData = mysqli_query($con, "SELECT * FROM tabletodo");
        ?>

        <div class="container">
            <div class="col-8 m-auto mt-3">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>List name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($listvalue = mysqli_fetch_array($rawData)) { ?>
                            <tr>
                                <td><?php echo $listvalue['list']; ?></td>
                                <td>
                                    <a href="update.php?list=<?php echo $listvalue['list']; ?>" class="btn btn-primary"><i class="fas fa-pen"></i></a>
                                    <a href="cancel.php?ID=<?php echo $listvalue['id']; ?>" class="btn btn-danger"><i class="fas fa-times"></i></a>
                                </td>
                            </tr>
                        <?php 

                    } 
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>
