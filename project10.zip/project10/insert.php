<?php
include "categories list.php";

if ($_SERVER["REQUEST_METHOD"] =="POST") {
    $listName = $_POST["list"];

  
    $query = "INSERT INTO tabletodo (list) VALUES ('$listName')";
    mysqli_query($con, $query);

 
    header("Location: index.php");
    exit();
}
?>
