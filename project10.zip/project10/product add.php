<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background-color: #333;
            color: white;
            padding: 15px;
            text-align: center;
        }

        nav {
            width: 200px;
            background-color: #f4f4f4;
            padding: 15px;
            position: fixed;
            height: 25%;
            overflow: auto;
        }

        nav a {
            display: block;
            padding: 15px;
            text-decoration: none;
            color: blue;
            border-bottom: 2px solid blue;
            border-right: 2px solid blue;
            border-left: 2px solid blue;
            border-top: 2px solid blue;
           
        }

        nav a:hover {
            background-color: #ddd;
        }

        .text p {
            color: blue;
            font-size: 20px;
            margin: 100px 0 0 300px;
        }
        .form input{
            margin-left:500px;
            border:2px solid blue;
            margin-top:70px;
            height: 30px;
            width: 25%;
            color:blue;
        }

        .btn button {
            color: blue;
            padding: 10px;
            width: 25%;
            border: 2px solid blue;
            margin: 300px 0 0 33%;
        }
        .t-center  .col-6{
            width:75%;
            margin:20px 0 0 0%;
        }

        .col-6 {
            margin-top: 80px;
            margin-left: 145px;
            margin-top: -0%;
            border: 2px solid blue;
            border-radius: 2.5%;
            display: inline-block; /* Display as inline-block to be in the same line */
        }

        .mb-3 {
            margin: 10% 0 0 16.5%;
            width: 50%;
            border: 2px solid blue;
            border-radius: 2.5%;
            display: inline-block; 
        }

        select {
            position: absolute;
            margin: 30px 0 0 -22px;
            align-items:center;
            width:30%; 

        }
        #inputState{
            width:28.2%;
            margin:20px 0 0 9.2%;
            border: 2px solid blue;
            border-radius: 2.5%;
        }
 User
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        header {
            background-color: #333;
            color: white;
            padding: 15px;
            text-align: center;
        }

        nav {
            width: 200px;
            background-color: #f4f4f4;
            padding: 15px;
            position: fixed;
            height: 25%;
            overflow: auto;
        }

        nav a {
            display: block;
            padding: 15px;
            text-decoration: none;
            color: blue;
            border-bottom: 2px solid blue;
            border-right: 2px solid blue;
            border-left: 2px solid blue;
            border-top: 2px solid blue;
           
        }

        nav a:hover {
            background-color: #ddd;
        }

        .text p {
            color: blue;
            font-size: 20px;
            margin: 100px 0 0 300px;
        }
        .form input{
            margin-left:500px;
            border:2px solid blue;
            margin-top:70px;
            height: 30px;
            width: 25%;
            color:blue;
        }

        .btn button {
            color: blue;
            padding: 10px;
            width: 25%;
            border: 2px solid blue;
            margin: 300px 0 0 33%;
        }
        .t-center  .col-6{
            width:75%;
            margin:20px 0 0 0%;
        }

        .col-6 {
            margin-top: 80px;
            margin-left: 142px;
            margin-top: -10%;
            border: 2px solid blue;
            border-radius: 2.5%;
            display: inline-block;
            color:blue; /* Display as inline-block to be in the same line */
        }

        .mb-3 {
            margin: 10% 0 0 16.5%;
            width: 50%;
            border: 2px solid blue;
            border-radius: 2.5%;
            display: inline-block; 
        }

        select {
            position: absolute;
            margin: 30px 0 0 -22px;
            align-items:center;
            width:30%; 

        }
        #inputState{
            width:28.2%;
            margin:20px 0 0 9.2%;
            border: 2px solid blue;
            border-radius: 2.5%;
        }
        .form-check1{
        
            display:flex;
            margin:-22px 0 0 33%;
            color:blue;
          
          
        }
        .form-check2{
        
        display:flex;
        margin:-22px 0 0 50%;
        color:blue;
     
      
    }
    .form-check3{
        
        display:flex;
        margin:-22px 0 0 33%;
        color:blue;
       
      
    }
    .form-check4{
    
    display:flex;
    margin:-22px 0 0 50%;
    color:blue;
   
  
}
h5{
    margin:5px 0 0 17%;
    font-size:17px;
    color:blue;
}
.cat-icon span{
            position:absolute;
            color:blue;
            font-size:50px;
            margin-top:-4%;
            margin-left:26%;
            border-radius: 80%;
            border:2px solid blue;
            padding: 20px;
                    
        }
        h3{
            color:blue;
            margin:80px 0 0 17%;
            font-size:20px;
        }
        .d-grid {
            margin:4% 0 0 28%;
           
        }

       
       
       
       
    </style>
</head>
<body>

    <header>
        <h1>Dashboard</h1>
    </header>

    <nav>
        <a href="Home.php" class="active">Dashboard</a>
        <a href="index.php">Categories</a>
        <a href="product page.php">Product</a>
    </nav>

    <div class="text">
        <p>Product Add</p>
    </div>

    <form action="insert.php" method="POST">
        <div class="container">
            <div class="t-auto m-auto mt-8 py-2 col-md-8">
                <div class="col-6 ">
                    <input type="text" name="list" class="form-control text-primary" placeholder="Product Name " aria-label="Username" aria-describedby="basic-addon1"> 
                </div>
                <div class="col-md-4 ">
                    
                    <select id="inputState" class="form-select text-primary">
                        <option selected>Product categories</option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                    </select>
                </div>

                <div class="mb-3">
                    <textarea class="form-control" rows="6" placeholder="Product Description"></textarea>
                </div>

                <h5>Product type</h5>
                <div class="form-check1">
                    
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                    <label class="form-check-label" for="flexCheckDefault">
                        Our Product 
                    </label>
              </div>
                    <div class="form-check2">
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckChec" checked>
                    <label class="form-check-label"  for="flexCheckChecked">
                        Third Party
                    </label>                   
                </div>
                <h5 style="margin:25px 0 0 17%; font-size:15px;">Product  Availablity</h5>
                <div class="form-check3">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                    <label class="form-check-label" for="flexRadioDefault1"> Available </label>
                </div>

                <div class="form-check4">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
                    <label class="form-check-label" for="flexRadioDefault2">
                        Out of Stock
                    </label>
                </div>

                <div class="product">
                    <h3>Product image</h3>
    </div>

                    <div class="cat-icon">
        <span class="material-symbols-outlined">mail</span>
    </div> 
                
            </div>
            <div class="d-grid gap-1 col-4">
                <button type="submit" class="btn btn-outline-primary">Add New Categories</button> 
            </div>
        </div>
    </form>

</body>
</html>
