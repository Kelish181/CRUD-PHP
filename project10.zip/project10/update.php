<?php 
include "categories list.php";

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $listvalue = $_POST['list'];  
}

$rawData = mysqli_query($con, "SELECT `id`, `list` FROM `tabletodo` WHERE 1");
$listvalue = mysqli_fetch_array($rawData);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
  
</head>

<body>

    <form action="index.php" method="POST">
        <div class="container">
            <div class="row justify-content-center m-auto shadow bg-white mt-3 py-3 col-md-6">
                <h3 class="text-center text-primary font-monospace">Update list</h3>
                <div class="col-5">
                    <input type="text" name="list" value="<?php echo isset($listvalue['list']) ? $listvalue['list'] : ''; ?>">
                </div>
                          
                <div class="col-2">
                    <button type="submit" name="update" class="btn btn-outline-primary"><i class="fa-solid fa-pen-to-square"></i></button>
                </div>
            </div>
        </div>
    </form>

</body>

</html>
